﻿
namespace UI_Layer
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonNewProduct = new System.Windows.Forms.Button();
            this.buttonShowProduct = new System.Windows.Forms.Button();
            this.labelProductnum = new System.Windows.Forms.Label();
            this.labelProductName = new System.Windows.Forms.Label();
            this.labelCostPerUnit = new System.Windows.Forms.Label();
            this.labelNumberInStock = new System.Windows.Forms.Label();
            this.textBoxProductNum = new System.Windows.Forms.TextBox();
            this.textBoxNumberInStock = new System.Windows.Forms.TextBox();
            this.textBoxCostPerUnit = new System.Windows.Forms.TextBox();
            this.textBoxProductName = new System.Windows.Forms.TextBox();
            this.textBoxProNum = new System.Windows.Forms.TextBox();
            this.textBoxNumInStock = new System.Windows.Forms.TextBox();
            this.textBoxCPU = new System.Windows.Forms.TextBox();
            this.textBoxProName = new System.Windows.Forms.TextBox();
            this.labelDelete = new System.Windows.Forms.Label();
            this.labelShow = new System.Windows.Forms.Label();
            this.labelModify = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonModifyEnter
            // 
            this.buttonModifyEnter.Location = new System.Drawing.Point(687, 345);
            this.buttonModifyEnter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonModifyEnter.TabIndex = 29;
            this.buttonModifyEnter.Click += new System.EventHandler(this.buttonModifyEnter_Click);
            // 
            // ButtonBackToMenu
            // 
            this.ButtonBackToMenu.Location = new System.Drawing.Point(12, 404);
            this.ButtonBackToMenu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ButtonBackToMenu.TabIndex = 19;
            this.ButtonBackToMenu.Click += new System.EventHandler(this.ButtonBackToMenu_Click);
            // 
            // ButtonShowAll
            // 
            this.ButtonShowAll.Click += new System.EventHandler(this.ButtonShowAll_Click);
            // 
            // textBoxReadAll
            // 
            this.textBoxReadAll.Location = new System.Drawing.Point(359, 270);
            this.textBoxReadAll.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxReadAll.Size = new System.Drawing.Size(306, 320);
            this.textBoxReadAll.TabIndex = 20;
            // 
            // InventoryLabel
            // 
            this.InventoryLabel.Location = new System.Drawing.Point(36, 67);
            this.InventoryLabel.TabIndex = 18;
            // 
            // ButtonDeleteEnter
            // 
            this.ButtonDeleteEnter.Location = new System.Drawing.Point(687, 345);
            this.ButtonDeleteEnter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ButtonDeleteEnter.TabIndex = 28;
            this.ButtonDeleteEnter.Click += new System.EventHandler(this.ButtonDeleteEnter_Click);
            // 
            // buttonEnterNew
            // 
            this.buttonEnterNew.Location = new System.Drawing.Point(687, 345);
            this.buttonEnterNew.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonEnterNew.TabIndex = 27;
            this.buttonEnterNew.Click += new System.EventHandler(this.buttonEnterNew_Click);
            // 
            // buttonEnterShowOne
            // 
            this.buttonEnterShowOne.Location = new System.Drawing.Point(687, 345);
            this.buttonEnterShowOne.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonEnterShowOne.TabIndex = 13;
            this.buttonEnterShowOne.Click += new System.EventHandler(this.buttonEnter_Click);
            // 
            // buttonNewProduct
            // 
            this.buttonNewProduct.Location = new System.Drawing.Point(0, 0);
            this.buttonNewProduct.Name = "buttonNewProduct";
            this.buttonNewProduct.Size = new System.Drawing.Size(75, 23);
            this.buttonNewProduct.TabIndex = 0;
            // 
            // buttonShowProduct
            // 
            this.buttonShowProduct.Location = new System.Drawing.Point(415, 155);
            this.buttonShowProduct.Name = "buttonShowProduct";
            this.buttonShowProduct.Size = new System.Drawing.Size(75, 23);
            this.buttonShowProduct.TabIndex = 2;
            // 
            // labelProductnum
            // 
            this.labelProductnum.AutoSize = true;
            this.labelProductnum.Font = new System.Drawing.Font("Segoe Script", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProductnum.Location = new System.Drawing.Point(49, 41);
            this.labelProductnum.Name = "labelProductnum";
            this.labelProductnum.Size = new System.Drawing.Size(239, 40);
            this.labelProductnum.TabIndex = 5;
            this.labelProductnum.Text = "Product number:";
            this.labelProductnum.Visible = false;
            // 
            // labelProductName
            // 
            this.labelProductName.AutoSize = true;
            this.labelProductName.Font = new System.Drawing.Font("Segoe Script", 13.8F, System.Drawing.FontStyle.Bold);
            this.labelProductName.Location = new System.Drawing.Point(49, 118);
            this.labelProductName.Name = "labelProductName";
            this.labelProductName.Size = new System.Drawing.Size(209, 40);
            this.labelProductName.TabIndex = 14;
            this.labelProductName.Text = "Product name:";
            this.labelProductName.Visible = false;
            // 
            // labelCostPerUnit
            // 
            this.labelCostPerUnit.AutoSize = true;
            this.labelCostPerUnit.Font = new System.Drawing.Font("Segoe Script", 13.8F, System.Drawing.FontStyle.Bold);
            this.labelCostPerUnit.Location = new System.Drawing.Point(49, 177);
            this.labelCostPerUnit.Name = "labelCostPerUnit";
            this.labelCostPerUnit.Size = new System.Drawing.Size(197, 40);
            this.labelCostPerUnit.TabIndex = 15;
            this.labelCostPerUnit.Text = "Cost per unit:";
            this.labelCostPerUnit.Visible = false;
            // 
            // labelNumberInStock
            // 
            this.labelNumberInStock.AutoSize = true;
            this.labelNumberInStock.Font = new System.Drawing.Font("Segoe Script", 13.8F, System.Drawing.FontStyle.Bold);
            this.labelNumberInStock.Location = new System.Drawing.Point(53, 242);
            this.labelNumberInStock.Name = "labelNumberInStock";
            this.labelNumberInStock.Size = new System.Drawing.Size(238, 40);
            this.labelNumberInStock.TabIndex = 16;
            this.labelNumberInStock.Text = "Number in stock:";
            this.labelNumberInStock.Visible = false;
            // 
            // textBoxProductNum
            // 
            this.textBoxProductNum.Location = new System.Drawing.Point(276, 18);
            this.textBoxProductNum.Name = "textBoxProductNum";
            this.textBoxProductNum.Size = new System.Drawing.Size(390, 22);
            this.textBoxProductNum.TabIndex = 9;
            this.textBoxProductNum.Visible = false;
            // 
            // textBoxNumberInStock
            // 
            this.textBoxNumberInStock.Location = new System.Drawing.Point(276, 194);
            this.textBoxNumberInStock.Name = "textBoxNumberInStock";
            this.textBoxNumberInStock.Size = new System.Drawing.Size(390, 22);
            this.textBoxNumberInStock.TabIndex = 10;
            this.textBoxNumberInStock.Visible = false;
            // 
            // textBoxCostPerUnit
            // 
            this.textBoxCostPerUnit.Location = new System.Drawing.Point(276, 128);
            this.textBoxCostPerUnit.Name = "textBoxCostPerUnit";
            this.textBoxCostPerUnit.Size = new System.Drawing.Size(390, 22);
            this.textBoxCostPerUnit.TabIndex = 11;
            this.textBoxCostPerUnit.Visible = false;
            // 
            // textBoxProductName
            // 
            this.textBoxProductName.Location = new System.Drawing.Point(276, 70);
            this.textBoxProductName.Name = "textBoxProductName";
            this.textBoxProductName.Size = new System.Drawing.Size(390, 22);
            this.textBoxProductName.TabIndex = 12;
            this.textBoxProductName.Visible = false;
            // 
            // textBoxProNum
            // 
            this.textBoxProNum.Location = new System.Drawing.Point(379, 80);
            this.textBoxProNum.Name = "textBoxProNum";
            this.textBoxProNum.Size = new System.Drawing.Size(374, 22);
            this.textBoxProNum.TabIndex = 21;
            this.textBoxProNum.Visible = false;
            // 
            // textBoxNumInStock
            // 
            this.textBoxNumInStock.Location = new System.Drawing.Point(379, 242);
            this.textBoxNumInStock.Name = "textBoxNumInStock";
            this.textBoxNumInStock.Size = new System.Drawing.Size(374, 22);
            this.textBoxNumInStock.TabIndex = 22;
            this.textBoxNumInStock.Visible = false;
            // 
            // textBoxCPU
            // 
            this.textBoxCPU.Location = new System.Drawing.Point(379, 187);
            this.textBoxCPU.Name = "textBoxCPU";
            this.textBoxCPU.Size = new System.Drawing.Size(374, 22);
            this.textBoxCPU.TabIndex = 23;
            this.textBoxCPU.Visible = false;
            // 
            // textBoxProName
            // 
            this.textBoxProName.Location = new System.Drawing.Point(379, 130);
            this.textBoxProName.Name = "textBoxProName";
            this.textBoxProName.Size = new System.Drawing.Size(374, 22);
            this.textBoxProName.TabIndex = 24;
            this.textBoxProName.Visible = false;
            // 
            // labelDelete
            // 
            this.labelDelete.AutoSize = true;
            this.labelDelete.Location = new System.Drawing.Point(13, 13);
            this.labelDelete.Name = "labelDelete";
            this.labelDelete.Size = new System.Drawing.Size(317, 17);
            this.labelDelete.TabIndex = 25;
            this.labelDelete.Text = "Enter number of product you would like to delete:";
            this.labelDelete.Visible = false;
            // 
            // labelShow
            // 
            this.labelShow.AutoSize = true;
            this.labelShow.Location = new System.Drawing.Point(13, 13);
            this.labelShow.Name = "labelShow";
            this.labelShow.Size = new System.Drawing.Size(312, 17);
            this.labelShow.TabIndex = 26;
            this.labelShow.Text = "Enter number of product you would like to Show:";
            this.labelShow.Visible = false;
            // 
            // labelModify
            // 
            this.labelModify.AutoSize = true;
            this.labelModify.Location = new System.Drawing.Point(12, 15);
            this.labelModify.Name = "labelModify";
            this.labelModify.Size = new System.Drawing.Size(497, 17);
            this.labelModify.TabIndex = 30;
            this.labelModify.Text = "Enter the number of the item you want to modify, and fill in all of its propertie" +
    "s:";
            this.labelModify.Visible = false;
            // 
            // ProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1062, 596);
            this.Controls.Add(this.labelModify);
            this.Controls.Add(this.labelShow);
            this.Controls.Add(this.labelDelete);
            this.Controls.Add(this.textBoxProName);
            this.Controls.Add(this.textBoxCPU);
            this.Controls.Add(this.textBoxNumInStock);
            this.Controls.Add(this.textBoxProNum);
            this.Controls.Add(this.labelNumberInStock);
            this.Controls.Add(this.labelCostPerUnit);
            this.Controls.Add(this.labelProductName);
            this.Controls.Add(this.labelProductnum);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.Name = "ProductForm";
            this.Text = "Product Manager List";
            this.Load += new System.EventHandler(this.ProductForm_Load);
            this.Controls.SetChildIndex(this.buttonNew, 0);
            this.Controls.SetChildIndex(this.ButtonShowAll, 0);
            this.Controls.SetChildIndex(this.buttonShow, 0);
            this.Controls.SetChildIndex(this.buttonDelete, 0);
            this.Controls.SetChildIndex(this.buttonModify, 0);
            this.Controls.SetChildIndex(this.labelProductnum, 0);
            this.Controls.SetChildIndex(this.buttonEnterShowOne, 0);
            this.Controls.SetChildIndex(this.labelProductName, 0);
            this.Controls.SetChildIndex(this.labelCostPerUnit, 0);
            this.Controls.SetChildIndex(this.labelNumberInStock, 0);
            this.Controls.SetChildIndex(this.ButtonBackToMenu, 0);
            this.Controls.SetChildIndex(this.InventoryLabel, 0);
            this.Controls.SetChildIndex(this.textBoxReadAll, 0);
            this.Controls.SetChildIndex(this.textBoxProNum, 0);
            this.Controls.SetChildIndex(this.textBoxNumInStock, 0);
            this.Controls.SetChildIndex(this.textBoxCPU, 0);
            this.Controls.SetChildIndex(this.textBoxProName, 0);
            this.Controls.SetChildIndex(this.labelDelete, 0);
            this.Controls.SetChildIndex(this.labelShow, 0);
            this.Controls.SetChildIndex(this.buttonEnterNew, 0);
            this.Controls.SetChildIndex(this.ButtonDeleteEnter, 0);
            this.Controls.SetChildIndex(this.buttonModifyEnter, 0);
            this.Controls.SetChildIndex(this.labelModify, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonNewProduct;
        private System.Windows.Forms.Button ButtonShowProducts;
        private System.Windows.Forms.Button buttonShowProduct;
        private System.Windows.Forms.Button buttonModifyProduct;
        private System.Windows.Forms.Button buttonDeleteProduct;
        private System.Windows.Forms.Label labelProductnum;
        private System.Windows.Forms.Button buttonEnterShowOne;
        private System.Windows.Forms.Label labelProductName;
        private System.Windows.Forms.Label labelCostPerUnit;
        private System.Windows.Forms.Label labelNumberInStock;
        private System.Windows.Forms.Button ButtonBackToMenu;
        private System.Windows.Forms.TextBox textBoxProductNum;
        private System.Windows.Forms.TextBox textBoxNumberInStock;
        private System.Windows.Forms.TextBox textBoxCostPerUnit;
        private System.Windows.Forms.TextBox textBoxProductName;
        private System.Windows.Forms.Label InventoryLabel;
        private System.Windows.Forms.TextBox textBoxReadAll;
        private System.Windows.Forms.TextBox textBoxProNum;
        private System.Windows.Forms.TextBox textBoxNumInStock;
        private System.Windows.Forms.TextBox textBoxCPU;
        private System.Windows.Forms.TextBox textBoxProName;
        private System.Windows.Forms.Label labelDelete;
        private System.Windows.Forms.Label labelShow;
        private System.Windows.Forms.Button buttonEnterNew;
        private System.Windows.Forms.Button ButtonDeleteEnter;
        private System.Windows.Forms.Button buttonModifyEnter;
        private System.Windows.Forms.Label labelModify;
    }
}

