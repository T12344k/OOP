﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entities;
using BL;
namespace UI_Layer
{
    public partial class OrderForm : Form
    {
        OrderBLL orderBll = new OrderBLL();
        ProductBL product = new ProductBL();
        CustomerBLL customerBLL = new CustomerBLL();
        public void ReadVisible()
        {
            labelOrderID.Visible = true;
            textBoxOrderID.Visible = true;
            textBoxOrders.Visible = true;
            buttonBackToMenu.Visible = true;
        }
        public void ReadUnvisible()
        {
            labelOrderID.Visible = false;
            textBoxOrderID.Visible = false;
            textBoxOrders.Visible = false;
        }

        public void ClearTextBoxes()
        {
            textBoxCustomerID.Clear();
            textBoxNewQuantity.Clear();
            textBoxOrderID.Clear();
            textBoxNewQuantity.Clear();
            textBoxOrders.Clear();
            
         //   
        }

        public void MakeOrderVisible()
        {
            textBoxCustomerID.Visible = true;
            textBoxQuantity.Visible = true;
            listBoxProductNumbers.Visible = true;
            buttonPlaceOrder.Visible = true;
            labelCustomerID.Visible = true;
            labelProducts.Visible = true;
            labelQuantity.Visible = true;
            buttonBackToMenu.Visible = true;
        }
        public void ModifyVisible()
        {
            labelOrderID.Visible = true;
            labelNewQuantity.Visible = true;
            textBoxOrderID.Visible = true;
            textBoxNewQuantity.Visible = true;
            buttonModifyOrder.Visible = true;
            buttonBackToMenu.Visible = true;
        }
        public void ModifyInvisible()
        {
            labelOrderID.Visible = false;
            labelNewQuantity.Visible = false;
            textBoxOrderID.Visible = false;
            textBoxNewQuantity.Visible = false;
            buttonModifyOrder.Visible = false;

        }

        public void MakeOrderInvisible()
        {
            textBoxCustomerID.Visible = false;
            textBoxQuantity.Visible = false;
            listBoxProductNumbers.Visible = false;
            buttonPlaceOrder.Visible = false;
            labelCustomerID.Visible = false;
            labelProducts.Visible = false;
            labelQuantity.Visible = false;
        }
        public void MakeOtherPropertiesVisible()
        {
            buttonNew.Visible = true;
            buttonModify.Visible = true;
            buttonDelete.Visible = true;
            buttonRead.Visible = true;
            buttonReadAll.Visible = true;
            buttonBackToMenu.Visible = false;
           // buttonPlaceOrder.Enabled = false;
        }
        public void MakeOtherPropertiesInvisble()
        {
            buttonNew.Visible = false;
            buttonModify.Visible = false;
            buttonDelete.Visible = false;
            buttonRead.Visible = false;
            buttonReadAll.Visible = false;
        }

        public OrderForm()
        {
            InitializeComponent();
            MakeOrderInvisible();
            ModifyInvisible();
            ReadUnvisible();
            buttonBackToMenu.Visible = false;
            buttonDeleteOrder.Visible = false;
            buttonEnter.Visible = false;
            listBoxOrders.Visible = false;
            buttonReadOrder.Visible = false;
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
            
        }
        private void FillListBox()
        {
            listBoxProductNumbers.DataSource = product.ReadAll();
        }
        private void buttonNew_Click(object sender, EventArgs e)
        {

            MakeOrderVisible();
            MakeOtherPropertiesInvisble();
            FillListBox();
            buttonBackToMenu.Visible = true;
            buttonEnter.Visible = false;
 




        }

        private void buttonPlaceOrder_Click(object sender, EventArgs e)
        {
            //check if he put in the customer id, selected a product number and entered the desired quantity for that product. 
            if (textBoxCustomerID.Text != string.Empty && listBoxProductNumbers.SelectedItem !=null && textBoxQuantity.Text != string.Empty)
            {
                try
                {
                    if (textBoxQuantity.Text != "0")
                    {
                        orderBll.Create((listBoxProductNumbers.SelectedItem as Product).Product_Number, textBoxCustomerID.Text, int.Parse(textBoxQuantity.Text));
                        //once ived done this, make all thingyiies visible, get rid of the other things quantity textobx etc.
                        textBoxCustomerID.Clear();
                        textBoxQuantity.Clear();
                        MakeOtherPropertiesVisible();
                        MakeOrderInvisible();
                    }
                    else
                    {
                        throw new Exception("Invalid Entry");
                    }
                   
                }

                //buttonPlaceOrder.Enabled = true;

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    textBoxQuantity.Clear();


                }
            }
            else
            {
                MessageBox.Show("please make sure you entered an ID, selected an item and entered a quantity.");
                
            }
            //check if he selected an item
            //check if he entered a quantity

            //put this in a TRY
           
        //if he did- create a new order
        }

        private void buttonModify_Click(object sender, EventArgs e)
        {
            labelCustomerID.Visible = true;
            textBoxCustomerID.Visible = true;
            MakeOtherPropertiesInvisble();
            buttonBackToMenu.Visible = true;
            buttonEnter.Visible = true;
            textBoxNewQuantity.Clear();
        }

        private void buttonModifyOrder_Click(object sender, EventArgs e)
        {
            {
                if (textBoxNewQuantity.Text != string.Empty && listBoxOrders.SelectedItem != null)
                    try
                    {
                        if (textBoxNewQuantity.Text != "0" )
                        { Order o = listBoxOrders.SelectedItem as Order;
                            // orderBll.Update(o.OrderID, new Order(o.ProductNumber, o.CustomerID, int.Parse(textBoxNewQuantity.Text), o.TimeofOrder));
                            int newQuantity = int.Parse(textBoxNewQuantity.Text);
                            orderBll.Update(o.OrderID, o, newQuantity);
                            listBoxOrders.DataSource = orderBll.ReadbyID(textBoxCustomerID.Text);
                            MessageBox.Show($"Order {textBoxCustomerID.Text} successfully updated.");
                        }
                        else
                        {
                            MessageBox.Show("Invalid entry");
                            textBoxNewQuantity.Clear();
                        }
                       
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message + " Unsuccessful attempt.");
                    }
                    finally
                    {
                        textBoxNewQuantity.Clear();
                    }
                //ClearBoxes();
                else
                {
                    MessageBox.Show("please make sure you entered an  order ID and a new quantity. ");
                }
            }
        }

        private void buttonRead_Click(object sender, EventArgs e)
        {
            MakeOrderInvisible();
            MakeOtherPropertiesInvisble();
            ReadVisible();
            buttonReadOrder.Visible = true;

            
 
        }

        private void buttonBackToMenu_Click(object sender, EventArgs e)
        {
            MakeOtherPropertiesVisible();
            MakeOrderInvisible();
            ModifyInvisible();
            ClearTextBoxes();
            buttonDeleteOrder.Visible = false;
            listBoxOrders.Visible = false;
            textBoxOrders.Visible = false;
            buttonReadOrder.Visible = false;
            buttonEnter.Visible = false;
        }

        private void buttonReadAll_Click(object sender, EventArgs e)
        {
            MakeOrderInvisible();
            MakeOtherPropertiesInvisble();
            listBoxOrders.Visible = true;
            buttonBackToMenu.Visible = true;
            listBoxOrders.DataSource = orderBll.ReadAll();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            MakeOrderInvisible();
            MakeOtherPropertiesInvisble();
            buttonBackToMenu.Visible = true;
            labelOrderID.Visible = true;
            textBoxOrderID.Visible = true;
            buttonDeleteOrder.Visible = true;
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {
            if (textBoxCustomerID.Text != string.Empty)
                try
                {
                    customerBLL.ReadbyID(textBoxCustomerID.Text);//checking that the customer exists. 
                    listBoxOrders.DataSource = orderBll.ReadbyID(textBoxCustomerID.Text);
                    listBoxOrders.Visible = true;
                    buttonEnter.Visible = false;
                    textBoxNewQuantity.Visible = true;
                    labelNewQuantity.Visible = true;
                    buttonModifyOrder.Visible = true;
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);

                }
            else
            {
                MessageBox.Show("Please enter an ID");
            }
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void buttonReadOrder_Click(object sender, EventArgs e)
        {
            if (textBoxOrderID.Text != null)
                try
                {
                     orderBll.Read(int.Parse(textBoxOrderID.Text));
                    textBoxOrders.Text = orderBll.Read(int.Parse(textBoxOrderID.Text)).ToString();
                   // ClearTextBoxes();
                   // buttonReadOrder.Visible = false;
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);

                }

            else
            {
                MessageBox.Show("Please enter an ID");
            }
        }

        private void buttonDeleteOrder_Click(object sender, EventArgs e)
        {
            if (textBoxOrderID.Text != string.Empty)
            {
                try
                {
                    orderBll.Delete(int.Parse(textBoxOrderID.Text));
                    ClearTextBoxes();

                    MessageBox.Show("Order successfully deleted");
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                    
                }
            
                //buttonDeleteOrder.Visible = false;
            }
            else
            {
                MessageBox.Show("Please enter an OrderID");
            }



        }

    }
}

