﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL;
using Entities;

namespace UI_Layer
{
    public partial class customerFormNew : BaseForm2
    {
        CustomerBLL CustomerBL;
        public customerFormNew()
        {
            CustomerBL = new CustomerBLL();//refers to a BL object. 
            InitializeComponent();
            DontShowPropertiesOfCustomer();
        }

        private void customerFormNew_Load(object sender, EventArgs e)
        {

        }
        #region ShowAndHide
        /// <summary>
        /// this method hides  all labels we dont want to be visible once doing a certain one of the CRUD methods. 
        /// it hides all the buttons and labels and textboxes once an enter button is clicked. 
        /// </summary>
        public void HideScreen()
        {
            textBoxReadAll.Visible = false;
            InventoryLabel.Visible = false;
            ButtonBackToMenu.Visible = false;
            labelCustomerIDNEW.Visible = false;
            labelCustomerNameNEW.Visible = false;
            labelCustomerCreditCardNEW.Visible = false;
            buttonEnterShowOne.Visible = false;
            textBoxCustomerIdNEW.Visible = false;
            textBoxCustomerNameNEW.Visible = false;
            textBoxCustomerCreditCardNEW.Visible = false;
            buttonDelete.Visible = false;
            ButtonDeleteEnter.Visible = false;
            buttonNew.Visible = false;
            buttonEnterNew.Visible = false;
            buttonShow.Visible = false;
            buttonModifyEnter.Visible = false;
            buttonEnterShowOne.Visible = false;
            ButtonShowAll.Visible = false;
            buttonModify.Visible = false;

        }
        /// <summary>
        /// does the opposite of HideScreen
        /// </summary>


        public void ShowScreen()
        {
            textBoxReadAll.Visible = true;
            InventoryLabel.Visible = true;
            ButtonBackToMenu.Visible = true;
            labelCustomerIDNEW.Visible = true;
            labelCustomerNameNEW.Visible = true;
            labelCustomerCreditCardNEW.Visible = true;
            buttonEnterShowOne.Visible = true;
            textBoxCustomerIdNEW.Visible = true;
            textBoxCustomerNameNEW.Visible = true;
            textBoxCustomerCreditCardNEW.Visible = true;
            buttonDelete.Visible = true;
            ButtonDeleteEnter.Visible = true;
            buttonNew.Visible = true;
            buttonEnterNew.Visible = true;
            buttonShow.Visible = true;
            buttonModifyEnter.Visible = true;
            buttonEnterShowOne.Visible = true;
            ButtonShowAll.Visible = true;
            buttonModify.Visible = true;

        }
        public void ShowPropertiesOfCustomer()
        {
            labelCustomerIDNEW.Visible = true;
            labelCustomerNameNEW.Visible = true;
            labelCustomerCreditCardNEW.Visible = true;
            ButtonBackToMenu.Visible = true;
            textBoxCustomerIdNEW.Visible = true;
            textBoxCustomerNameNEW.Visible = true;
            textBoxCustomerCreditCardNEW.Visible = true;
            //labelDeleteNEW.Visible = false;
            //labelShowNEW.Visible = false;
            //buttonModifyEnter.Visible = false;
            //buttonEnterShowOne.Visible = false;
            //buttonEnterNew.Visible = false;
            //ButtonDeleteEnter.Visible = false;
            // PanelProperties.Visible = true;

        }
        public void ShowPropertiesOfCustomerShow()
        {
            labelCustomerIDNEW.Visible = true;
            labelCustomerNameNEW.Visible = false;
            labelCustomerCreditCardNEW.Visible = false;
            ButtonBackToMenu.Visible = true;
            textBoxCustomerIdNEW.Visible = true;
            textBoxCustomerNameNEW.Visible = false;
            textBoxCustomerCreditCardNEW.Visible = false;
            buttonModifyEnter.Visible = false;
            buttonEnterShowOne.Visible = false;
            buttonEnterNew.Visible = false;
            ButtonDeleteEnter.Visible = false;
            // PanelProperties.Visible = true;

        }
        /// <summary>
        /// does the opposite of ShowPropertiesofCustomer
        /// </summary>
        public void DontShowPropertiesOfCustomer()
        {
            labelCustomerIDNEW.Visible = false;
            labelCustomerNameNEW.Visible = false;
            labelCustomerCreditCardNEW.Visible = false;
            ButtonBackToMenu.Visible = false;
            textBoxCustomerIdNEW.Visible = false;
            textBoxCustomerNameNEW.Visible = false;
            textBoxCustomerCreditCardNEW.Visible = false;
            //labelDeleteNEW.Visible = true;
            //labelShowNEW.Visible = true;
            //buttonModifyEnter.Visible = true;
            //buttonEnterShowOne.Visible = true;
            //buttonEnterNew.Visible = true;
            //ButtonDeleteEnter.Visible = true;
            // PanelProperties.Visible = true;
        }
        public void HideEnterButton()
        {
            buttonEnterNew.Visible = false;
            buttonEnterShowOne.Visible = false;
            ButtonDeleteEnter.Visible = false;
            buttonModifyEnter.Visible = false;

        }

    /// <summary>
    /// it clears the information the user gave in for the customer
    /// </summary>
    public void ClearBoxes()
    {
            textBoxCustomerIdNEW.Clear();
            textBoxCustomerNameNEW.Clear();
            textBoxCustomerCreditCardNEW.Clear();

    }
    #endregion
    #region IMPLEMENTCRUDMETHODS
    protected override void ImplementNew()
    {
            HideEnterButton();
            InventoryLabel.Visible = false;
            ShowPropertiesOfCustomer();
            buttonEnterNew.Visible = true;
    }
    protected override void ImplementShow()
    {
        ShowPropertiesOfCustomerShow();


    }
    protected override void ImplementModify()
    {
            ShowPropertiesOfCustomer();
            HideEnterButton();
            buttonModifyEnter.Visible = true;
            InventoryLabel.Visible = false;
        }
    protected override void ImplementDelete()
    {
            DontShowPropertiesOfCustomer();
            HideEnterButton();
            ButtonDeleteEnter.Visible = true;
            textBoxCustomerIdNEW.Visible = true;
            labelCustomerIDNEW.Visible = true;
            InventoryLabel.Visible = false;

        }

    //this is show all button, with naming issues
    protected override void ImplementShowAll()
    {
            HideEnterButton();
            DontShowPropertiesOfCustomer();
            ButtonBackToMenu.Visible = true;
            textBoxReadAll.Visible = true;

           
            try
            {

                foreach (Customer cust in CustomerBL.ReadAll())
                {
                    textBoxReadAll.AppendText(cust.ToString() + "\r\n");

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "Unsuccessful attempt.");
            }
        }
    #endregion

    private void buttonNew_Click(object sender, EventArgs e)
    {

    }

   
  
   
    /// <summary>Ya
    /// what happens when i enter show one 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void buttonEnterShowOne_Click(object sender, EventArgs e)
    {
        
    }

    private void ButtonShowAll_Click(object sender, EventArgs e)
    {
           
    }
    

      
        private void buttonModifyEnter_Click(object sender, EventArgs e)
        { 
        }
        

        
    




    private void ButtonDeleteEnter_Click(object sender, EventArgs e)
    
        {
            try
            {
                CustomerBL.Delete(textBoxCustomerIdNEW.Text);

                MessageBox.Show($"Customer {textBoxCustomerIdNEW.Text} successfully deleted.");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " Unsuccessful attempt.");
            }
            ClearBoxes();
        }
    

    private void customerFormNew_Load_1(object sender, EventArgs e)
    {

    }

    private void buttonModify_Click(object sender, EventArgs e)
    {

    }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// when the new customer button is clicked, it reads the customer id and then adds a new customer. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// what happens when i click enterNew
        private void buttonEnterNew_Click_1(object sender, EventArgs e)
        {
            try
            {
                
                CustomerBL.Create(textBoxCustomerIdNEW.Text, textBoxCustomerNameNEW.Text, new CreditCard(textBoxCustomerNameNEW.Text, textBoxCustomerCreditCardNEW.Text, default(DateTime)));

                MessageBox.Show($"customer {textBoxCustomerIdNEW.Text} successfully added. \r\n customer name: {textBoxCustomerNameNEW.Text}\r\n  customer credit card: {textBoxCustomerCreditCardNEW.Text} \r\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "Unsuccessful attempt.");
            }
            ClearBoxes();
            buttonEnterNew.Enabled = true;
        }

        private void ButtonBackToMenu_Click_1(object sender, EventArgs e)
        {
            ShowScreen();
            DontShowPropertiesOfCustomer();
            HideEnterButton();
            textBoxReadAll.Clear();
            textBoxReadAll.Visible = false;
            InventoryLabel.Visible = false;
        }

        private void ButtonShowAll_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonShow_Click(object sender, EventArgs e)
        {

        }

        private void buttonEnterShowOne_Click_1(object sender, EventArgs e)
        {
            try
            {
                //CustomerBLL productBL = new CustomerBLL();
                CustomerBL.Read(textBoxCustomerIdNEW.Text);
                HideScreen();

                textBoxReadAll.Text = CustomerBL.Read(textBoxCustomerIdNEW.Text).ToString(); //+ "\r\n");
                textBoxReadAll.Visible = true;
                ButtonBackToMenu.Visible = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "Unsuccessful attempt.");
            }
        }
        /// <summary>
        /// this method updates either the customer Name, customer CreditCard or both, based on the Customer ID. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonModifyEnter_Click_1(object sender, EventArgs e)
        
            {
                try
                {

                    Customer updatedCustomer = new Customer(new CreditCard(textBoxCustomerNameNEW.Text, textBoxCustomerCreditCardNEW.Text, default(DateTime)), textBoxCustomerNameNEW.Text, textBoxCustomerIdNEW.Text);
                    CustomerBL.Update(textBoxCustomerIdNEW.Text, updatedCustomer);
                    MessageBox.Show($"Customer {textBoxCustomerIdNEW.Text} successfully updated.");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "Unsuccessful attempt.");
                }
                ClearBoxes();
            }
    }
}