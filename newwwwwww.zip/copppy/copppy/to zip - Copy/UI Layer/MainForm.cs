﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI_Layer
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            labeldisplay.Visible = true;

        }
 
        private void buttonChoseProduct_Click(object sender, EventArgs e)
        {
         
            
            ProductFormNew product = new ProductFormNew();
            product.Visible = true;
            
            // Application.Run(new ProductFormNew());



        }

        private void buttonChoseCustomer_Click(object sender, EventArgs e)
        {
       
            customerFormNew customer = new customerFormNew();
            customer.Visible = true;
            //Application.Run(new customerFormNew());
        }

        private void labeldisplay_Click(object sender, EventArgs e)
        {

        }
        //this is order button, being stubborn
        private void button1_Click(object sender, EventArgs e)
        {

            OrderForm order = new OrderForm();
            order.Visible = true;
        }
    }
}
