﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI_Layer
{
    public partial class CustomerForm : BaseForm//if it inherits from baseform and baseform automatically inherits also from form, customerform automatically also inherits from form, right?
    {
        public CustomerForm()
        {
            InitializeComponent();
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {

        }
        protected override void New_Method()
        {
            labelNuber.Visible = true;
            textBoxNumber.Visible = true;
            labelName.Visible = true;
            textBoxName.Visible = true;
            labelCost.Visible = true;
            textBoxCost.Visible = true;
            labelAmount.Visible = true;
            textBoxAmount.Visible = true;



        }
        
    }
}
