﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL;
using Entities;
using DAL;

namespace UI_Layer
{
    public partial class ProductFormNew : BaseForm2
    {
        ProductBL productBL;
        public ProductFormNew()
        {
            productBL = new ProductBL();
            InitializeComponent();
            DontShowPropertiesofProduct();

        }

        private void ProductFormNew_Load(object sender, EventArgs e)
        {

        }
        #region ShowAndHide
        public void ShowPropertiesOFProduct()
        {
            labelCostPerUnit.Visible = true;
            labelProductNum.Visible = true;
            labelProductName.Visible = true;
            labelNumberInStock.Visible = true;
            textBoxAmountInStock.Visible = true;
            textBoxCostPerUnit.Visible = true;
            textBoxProductName.Visible = true;
            textBoxProductNum.Visible = true;

        }
        public void ShowScreen()
        {
            textBoxReadAll.Visible = true;
            InventoryLabel.Visible = true;
            ButtonBackToMenu.Visible = true;
            labelProductNum.Visible = true;
            labelProductName.Visible = true;
            labelNumberInStock.Visible = true;
            labelCostPerUnit.Visible = true;
            buttonEnterShowOne.Visible = true;
            textBoxProductNum.Visible = true;
            textBoxProductName.Visible = true;
            textBoxCostPerUnit.Visible = true;
            textBoxAmountInStock.Visible = true;
            buttonDelete.Visible = true;
            ButtonDeleteEnter.Visible = true;
            buttonNew.Visible = true;
            buttonEnterNew.Visible = true;
            buttonShow.Visible = true;
            buttonModifyEnter.Visible = true;
            buttonEnterShowOne.Visible = true;
            ButtonShowAll.Visible = true;
            buttonModify.Visible = true;
        }
        public void DontShowPropertiesofProduct()
        {
            labelCostPerUnit.Visible = false;
            labelProductNum.Visible = false;
            labelProductName.Visible = false;
            labelNumberInStock.Visible = false;
            textBoxAmountInStock.Visible = false;
            textBoxCostPerUnit.Visible = false;
            textBoxProductName.Visible = false;
            textBoxProductNum.Visible = false;

        }
        public void HideButtonEnter()
        {
            buttonEnterNew.Visible = false;
            buttonEnterShowOne.Visible = false;
            buttonModifyEnter.Visible = false;
            ButtonDeleteEnter.Visible = false;

        }
        public void Hidescreen()
        {
            textBoxReadAll.Visible = false;
            InventoryLabel.Visible = false;
            ButtonBackToMenu.Visible = false;
            labelProductNum.Visible = false;
            labelProductName.Visible = false;
            labelCostPerUnit.Visible = false;
            labelNumberInStock.Visible = false;
            buttonEnterShowOne.Visible = false;
            textBoxProductNum.Visible = false;
            textBoxProductName.Visible = false;
            textBoxCostPerUnit.Visible = false;
            textBoxAmountInStock.Visible = false;
            buttonDelete.Visible = false;
            ButtonDeleteEnter.Visible = false;
            buttonNew.Visible = false;
            buttonEnterNew.Visible = false;
            buttonShow.Visible = false;
            buttonModifyEnter.Visible = false;
            buttonEnterShowOne.Visible = false;
            ButtonShowAll.Visible = false;
            buttonModify.Visible = false;
           
        }
        public void ClearBoxes()
        {
            textBoxAmountInStock.Clear();
            textBoxProductName.Clear();
            textBoxProductNum.Clear();
            textBoxCostPerUnit.Clear();
        }
        
        #endregion
        #region IMPLEMENTCRUDMETHODS
        protected override void ImplementNew()
        {
            HideButtonEnter();
            buttonEnterNew.Visible = true;
            ShowPropertiesOFProduct();
            buttonEnterNew.Visible = true;
            InventoryLabel.Visible = false;
            

        }
        protected override void ImplementShow()
        {
            ShowPropertiesOFProduct(); 

        }
        protected override void ImplementModify()
        {
            ShowPropertiesOFProduct();
            HideButtonEnter();
            buttonModifyEnter.Visible = true;
            InventoryLabel.Visible = false;
        }
        protected override void ImplementDelete()
        {
            HideButtonEnter();
            ButtonDeleteEnter.Visible = true;
            DontShowPropertiesofProduct();
            textBoxProductNum.Visible = true;
            labelProductNum.Visible = true;
            InventoryLabel.Visible = false;

        }

        //this is show all button, with naming issues
        protected override void ImplementShowAll()
        {
            HideButtonEnter();
            DontShowPropertiesofProduct();
            ButtonBackToMenu.Visible = true;
            textBoxReadAll.Visible = true;


            try
            {

                foreach (Product product in productBL.ReadAll())
                {
                    textBoxReadAll.AppendText(product.ToString() + "\r\n");

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "Unsuccessful attempt.");
            }
        }
        #endregion

    
        private void buttonEnterNew_Click(object sender, EventArgs e)
        {
            try
            {
                
                InventoryLabel.Visible = false;
                productBL.Create(textBoxProductNum.Text, textBoxProductName.Text, double.Parse(textBoxCostPerUnit.Text), int.Parse(textBoxAmountInStock.Text));
                InventoryLabel.Visible = false;
                MessageBox.Show($"Product {textBoxProductNum.Text} successfully added. \r\n product name: {textBoxProductName.Text}\r\n  product cost: {textBoxCostPerUnit.Text} \r\n amount in stock: {textBoxAmountInStock.Text}");
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "Unsuccessful attempt.");
            }
            ClearBoxes();
            buttonEnterNew.Enabled = true;
        }
        private void buttonEnterShowOne_Click(object sender, EventArgs e)
        {
            try
            {
                InventoryLabel.Visible = false;
                Hidescreen();
                InventoryLabel.Visible = false;
                productBL.Read(textBoxProductNum.Text);
                textBoxReadAll.Text = productBL.Read(textBoxProductNum.Text).ToString(); //+ "\r\n");
                textBoxReadAll.Visible = true;
                ButtonBackToMenu.Visible = true;
                textBoxProductNum.Clear();
            
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "Unsuccessful attempt.");
            }

        }
        private void ButtonDeleteEnter_Click(object sender, EventArgs e)
        {
            try
            {
                InventoryLabel.Visible = false;
                HideButtonEnter();
                ButtonDeleteEnter.Visible = true;
                InventoryLabel.Visible = false;
                productBL.Delete(textBoxProductNum.Text);
                MessageBox.Show($"Product {textBoxProductNum.Text} successfully deleted.");
                InventoryLabel.Visible = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " Unsuccessful attempt.");
            }
            ClearBoxes();
        }
        private void buttonModifyEnter_Click(object sender, EventArgs e)
        {
            try
            {
                InventoryLabel.Visible = false;
                HideButtonEnter();
                buttonModifyEnter.Visible = true;
               // ButtonBackToMenu.Visible = true;

                Product updatedproduct = new Product(textBoxProductNum.Text, textBoxProductName.Text, double.Parse(textBoxCostPerUnit.Text), int.Parse(textBoxAmountInStock.Text));
                productBL.Update(textBoxProductNum.Text, updatedproduct);

                MessageBox.Show($"Product {textBoxProductNum.Text} successfully updated.");
                InventoryLabel.Visible = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "Unsuccessful attempt.");
            }
            ClearBoxes();
        }





        #region todelete

        private void buttonNew_Click(object sender, EventArgs e)
        {
            

        }



        #endregion

        private void ButtonBackToMenu_Click(object sender, EventArgs e)
        {
            ShowScreen();
            DontShowPropertiesofProduct();
            HideButtonEnter();
            textBoxReadAll.Clear();
            textBoxReadAll.Visible = false;
            InventoryLabel.Visible = false;
            ButtonBackToMenu.Visible = false;
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            textBoxAmountInStock.Visible = false;
            textBoxCostPerUnit.Visible = false;
            textBoxProductName.Visible = false;
            labelCostPerUnit.Visible = false;
            labelNumberInStock.Visible = false;
            labelProductName.Visible = false;
            buttonEnterNew.Visible = false;
            buttonModifyEnter.Visible = false;
            buttonEnterNew.Visible = false;
            ButtonDeleteEnter.Visible = false;
            
        }

        private void buttonModify_Click(object sender, EventArgs e)
        {

        }
    }
}
