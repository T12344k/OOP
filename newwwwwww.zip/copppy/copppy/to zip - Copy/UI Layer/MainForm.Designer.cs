﻿
namespace UI_Layer
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonChoseProduct = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.buttonChoseCustomer = new System.Windows.Forms.Button();
            this.labeldisplay = new System.Windows.Forms.Label();
            this.OrderButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonChoseProduct
            // 
            this.buttonChoseProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonChoseProduct.Font = new System.Drawing.Font("Segoe Print", 30F);
            this.buttonChoseProduct.Location = new System.Drawing.Point(24, 58);
            this.buttonChoseProduct.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonChoseProduct.Name = "buttonChoseProduct";
            this.buttonChoseProduct.Size = new System.Drawing.Size(372, 354);
            this.buttonChoseProduct.TabIndex = 0;
            this.buttonChoseProduct.Text = "Product";
            this.buttonChoseProduct.UseVisualStyleBackColor = false;
            this.buttonChoseProduct.Click += new System.EventHandler(this.buttonChoseProduct_Click);
            // 
            // buttonChoseCustomer
            // 
            this.buttonChoseCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonChoseCustomer.Font = new System.Drawing.Font("Segoe Print", 30F);
            this.buttonChoseCustomer.Location = new System.Drawing.Point(420, 58);
            this.buttonChoseCustomer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonChoseCustomer.Name = "buttonChoseCustomer";
            this.buttonChoseCustomer.Size = new System.Drawing.Size(372, 354);
            this.buttonChoseCustomer.TabIndex = 1;
            this.buttonChoseCustomer.Text = "Customer";
            this.buttonChoseCustomer.UseVisualStyleBackColor = false;
            this.buttonChoseCustomer.Click += new System.EventHandler(this.buttonChoseCustomer_Click);
            // 
            // labeldisplay
            // 
            this.labeldisplay.Font = new System.Drawing.Font("Segoe Print", 15F);
            this.labeldisplay.Location = new System.Drawing.Point(42, 7);
            this.labeldisplay.Name = "labeldisplay";
            this.labeldisplay.Size = new System.Drawing.Size(945, 49);
            this.labeldisplay.TabIndex = 2;
            this.labeldisplay.Text = "Welcome! Please choose either product, customer or make an order";
            this.labeldisplay.Click += new System.EventHandler(this.labeldisplay_Click);
            // 
            // OrderButton
            // 
            this.OrderButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.OrderButton.Font = new System.Drawing.Font("Segoe Print", 30F);
            this.OrderButton.Location = new System.Drawing.Point(823, 58);
            this.OrderButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.OrderButton.Name = "OrderButton";
            this.OrderButton.Size = new System.Drawing.Size(372, 354);
            this.OrderButton.TabIndex = 3;
            this.OrderButton.Text = "Order";
            this.OrderButton.UseVisualStyleBackColor = false;
            this.OrderButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1233, 476);
            this.Controls.Add(this.OrderButton);
            this.Controls.Add(this.labeldisplay);
            this.Controls.Add(this.buttonChoseCustomer);
            this.Controls.Add(this.buttonChoseProduct);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonChoseProduct;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button buttonChoseCustomer;
        private System.Windows.Forms.Label labeldisplay;
        private System.Windows.Forms.Button OrderButton;
    }
}