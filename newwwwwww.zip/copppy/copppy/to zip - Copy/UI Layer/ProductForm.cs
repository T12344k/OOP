﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL;
using Entities;
using DAL;
namespace UI_Layer
{
    public partial class ProductForm : BaseForm2
    {
        ProductBL productBL;
        public ProductForm()
        {
            productBL = new ProductBL();
            InitializeComponent();
        }
    


public void ShowPropertiesOfProduct()
{
    labelCostPerUnit.Visible = true;
    labelNumberInStock.Visible = true;
    labelProductName.Visible = true;
    labelProductnum.Visible = true;
    // buttonEnterShowOne.Visible = true;
    ButtonBackToMenu.Visible = true;
    textBoxCPU.Visible = true;
    textBoxNumInStock.Visible = true;
    textBoxProName.Visible = true;
    textBoxProNum.Visible = true;
    labelDelete.Visible = false;
    labelShow.Visible = false;
    buttonModifyEnter.Visible = false;
    buttonEnterShowOne.Visible = false;
    buttonEnterNew.Visible = false;
    ButtonDeleteEnter.Visible = false;
    // PanelProperties.Visible = true;
}
protected override void ImplementNew()
{
    ShowPropertiesOfProduct();
}
protected override void ImplementShow()
{
    labelProductnum.Visible = true;
    textBoxProNum.Visible = true;
    labelShow.Visible = true;


}
protected override void ImplementModify()
{
    ShowPropertiesOfProduct();
    labelModify.Visible = true;
}
protected override void ImplementDelete()
{
    labelProductnum.Visible = true;
    textBoxProNum.Visible = true;
    labelDelete.Visible = true;
}
//this is show all button, with naming issues
protected override void ImplementShowAll()
{
    try
    {

        foreach (Product prop in productBL.ReadAll())
        {
            textBoxReadAll.AppendText(prop.ToString() + "\r\n");

        }

    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message + "Unsuccessful attempt.");
    }
}


public void HideScreen()
{
    textBoxReadAll.Visible = false;
    InventoryLabel.Visible = false;
    ButtonBackToMenu.Visible = false;
    labelCostPerUnit.Visible = false;
    labelNumberInStock.Visible = false;
    labelProductName.Visible = false;
    labelProductnum.Visible = false;
    buttonEnterShowOne.Visible = false;
    textBoxCPU.Visible = false;
    textBoxNumInStock.Visible = false;
    textBoxProName.Visible = false;
    textBoxProNum.Visible = false;
    labelShow.Visible = false;
    labelDelete.Visible = false;
    buttonDeleteProduct.Visible = false;
    buttonModifyProduct.Visible = false;
    buttonNewProduct.Visible = false;
    buttonShowProduct.Visible = false;
    ButtonShowProducts.Visible = false;
    buttonModifyEnter.Visible = false;
    buttonEnterShowOne.Visible = false;
    buttonEnterNew.Visible = false;
    ButtonDeleteEnter.Visible = false;
    labelModify.Visible = false;

}

//This method does not work
public bool DidYouPressEnter(KeyEventArgs e)
{
    bool enterPressed = false;
    if (e.KeyCode == Keys.Enter)
    {
        enterPressed = true;
    }
    return enterPressed;
}


public void ClearBoxes()
{
    textBoxCPU.Clear();
    textBoxNumInStock.Clear();
    textBoxProName.Clear();
    textBoxProNum.Clear();
}

//this is show product enter, with naming issues
private void buttonEnter_Click(object sender, EventArgs e)
{
    try
    {
        // ProductBL productBL = new ProductBL();
        productBL.Read(textBoxProNum.Text);
        HideScreen();

        textBoxReadAll.Text = productBL.Read(textBoxProNum.Text).ToString(); //+ "\r\n");
        textBoxReadAll.Visible = true;
        ButtonBackToMenu.Visible = true;

    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message + "Unsuccessful attempt.");
    }

}

private void buttonModifyEnter_Click(object sender, EventArgs e)
{
    try
    {
        Product updatedProduct = new Product(textBoxProNum.Text, textBoxProName.Text, double.Parse(textBoxCPU.Text), int.Parse(textBoxNumInStock.Text));
        productBL.Update(textBoxProNum.Text, updatedProduct);

        MessageBox.Show($"Product {textBoxProNum.Text} successfully updated.");

    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message + "Unsuccessful attempt.");
    }
    ClearBoxes();
}

private void ButtonDeleteEnter_Click(object sender, EventArgs e)
{
    try
    {
        productBL.Delete(textBoxProNum.Text);

        MessageBox.Show($"Product {textBoxProNum.Text} successfully deleted.");

    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message + " Unsuccessful attempt.");
    }
    ClearBoxes();
}

private void buttonEnterNew_Click(object sender, EventArgs e)
{
    try
    {
        //if (textBoxProductNum.Modified)
        //{
        //   ProductBL productBL = new ProductBL();
        productBL.Create(textBoxProNum.Text, textBoxProName.Text, double.Parse(textBoxCPU.Text), int.Parse(textBoxNumInStock.Text));

        MessageBox.Show($"Product {textBoxProNum.Text} successfully added. \r\n Product name: {textBoxProName.Text}\r\n  Cost per unit: {textBoxCPU.Text} \r\n Number in stock: {textBoxNumInStock.Text}");
    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message + "Unsuccessful attempt.");
    }
    ClearBoxes();
}

private void ProductForm_Load(object sender, EventArgs e)
{

}

        private void ButtonBackToMenu_Click(object sender, EventArgs e)
        {

        }

        private void ButtonShowAll_Click(object sender, EventArgs e)
        {

        }
    }

}

