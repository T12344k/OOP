﻿
namespace UI_Layer
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonNew = new System.Windows.Forms.Button();
            this.buttonModify = new System.Windows.Forms.Button();
            this.buttonRead = new System.Windows.Forms.Button();
            this.buttonReadAll = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.textBoxCustomerID = new System.Windows.Forms.TextBox();
            this.textBoxQuantity = new System.Windows.Forms.TextBox();
            this.listBoxProductNumbers = new System.Windows.Forms.ListBox();
            this.buttonPlaceOrder = new System.Windows.Forms.Button();
            this.labelCustomerID = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            this.labelProducts = new System.Windows.Forms.Label();
            this.textBoxOrderID = new System.Windows.Forms.TextBox();
            this.textBoxNewQuantity = new System.Windows.Forms.TextBox();
            this.labelOrderID = new System.Windows.Forms.Label();
            this.labelNewQuantity = new System.Windows.Forms.Label();
            this.buttonModifyOrder = new System.Windows.Forms.Button();
            this.textBoxOrders = new System.Windows.Forms.TextBox();
            this.buttonBackToMenu = new System.Windows.Forms.Button();
            this.buttonDeleteOrder = new System.Windows.Forms.Button();
            this.buttonEnter = new System.Windows.Forms.Button();
            this.listBoxOrders = new System.Windows.Forms.ListBox();
            this.buttonReadOrder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonNew
            // 
            this.buttonNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonNew.Font = new System.Drawing.Font("Segoe Print", 14F);
            this.buttonNew.Location = new System.Drawing.Point(11, 23);
            this.buttonNew.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonNew.Name = "buttonNew";
            this.buttonNew.Size = new System.Drawing.Size(234, 62);
            this.buttonNew.TabIndex = 0;
            this.buttonNew.Text = "New order ";
            this.buttonNew.UseVisualStyleBackColor = false;
            this.buttonNew.Click += new System.EventHandler(this.buttonNew_Click);
            // 
            // buttonModify
            // 
            this.buttonModify.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.buttonModify.Font = new System.Drawing.Font("Segoe Print", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonModify.Location = new System.Drawing.Point(11, 94);
            this.buttonModify.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonModify.Name = "buttonModify";
            this.buttonModify.Size = new System.Drawing.Size(234, 58);
            this.buttonModify.TabIndex = 1;
            this.buttonModify.Text = "Modify order";
            this.buttonModify.UseVisualStyleBackColor = false;
            this.buttonModify.Click += new System.EventHandler(this.buttonModify_Click);
            // 
            // buttonRead
            // 
            this.buttonRead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonRead.Font = new System.Drawing.Font("Segoe Print", 14F);
            this.buttonRead.Location = new System.Drawing.Point(11, 161);
            this.buttonRead.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonRead.Name = "buttonRead";
            this.buttonRead.Size = new System.Drawing.Size(234, 54);
            this.buttonRead.TabIndex = 2;
            this.buttonRead.Text = "Read order";
            this.buttonRead.UseVisualStyleBackColor = false;
            this.buttonRead.Click += new System.EventHandler(this.buttonRead_Click);
            // 
            // buttonReadAll
            // 
            this.buttonReadAll.BackColor = System.Drawing.Color.HotPink;
            this.buttonReadAll.Font = new System.Drawing.Font("Segoe Print", 14F);
            this.buttonReadAll.Location = new System.Drawing.Point(11, 223);
            this.buttonReadAll.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonReadAll.Name = "buttonReadAll";
            this.buttonReadAll.Size = new System.Drawing.Size(234, 55);
            this.buttonReadAll.TabIndex = 3;
            this.buttonReadAll.Text = "Read all orders";
            this.buttonReadAll.UseVisualStyleBackColor = false;
            this.buttonReadAll.Click += new System.EventHandler(this.buttonReadAll_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.buttonDelete.Font = new System.Drawing.Font("Segoe Print", 14F);
            this.buttonDelete.Location = new System.Drawing.Point(11, 285);
            this.buttonDelete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(234, 61);
            this.buttonDelete.TabIndex = 4;
            this.buttonDelete.Text = "Delete order";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // textBoxCustomerID
            // 
            this.textBoxCustomerID.Location = new System.Drawing.Point(418, 44);
            this.textBoxCustomerID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxCustomerID.Name = "textBoxCustomerID";
            this.textBoxCustomerID.Size = new System.Drawing.Size(156, 22);
            this.textBoxCustomerID.TabIndex = 5;
            // 
            // textBoxQuantity
            // 
            this.textBoxQuantity.Location = new System.Drawing.Point(427, 106);
            this.textBoxQuantity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxQuantity.Name = "textBoxQuantity";
            this.textBoxQuantity.Size = new System.Drawing.Size(156, 22);
            this.textBoxQuantity.TabIndex = 7;
            // 
            // listBoxProductNumbers
            // 
            this.listBoxProductNumbers.FormattingEnabled = true;
            this.listBoxProductNumbers.ItemHeight = 16;
            this.listBoxProductNumbers.Location = new System.Drawing.Point(188, 157);
            this.listBoxProductNumbers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBoxProductNumbers.Name = "listBoxProductNumbers";
            this.listBoxProductNumbers.Size = new System.Drawing.Size(984, 196);
            this.listBoxProductNumbers.TabIndex = 8;
            // 
            // buttonPlaceOrder
            // 
            this.buttonPlaceOrder.Location = new System.Drawing.Point(17, 285);
            this.buttonPlaceOrder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonPlaceOrder.Name = "buttonPlaceOrder";
            this.buttonPlaceOrder.Size = new System.Drawing.Size(165, 30);
            this.buttonPlaceOrder.TabIndex = 9;
            this.buttonPlaceOrder.Text = "place order";
            this.buttonPlaceOrder.UseVisualStyleBackColor = true;
            this.buttonPlaceOrder.Click += new System.EventHandler(this.buttonPlaceOrder_Click);
            // 
            // labelCustomerID
            // 
            this.labelCustomerID.AutoSize = true;
            this.labelCustomerID.Location = new System.Drawing.Point(188, 49);
            this.labelCustomerID.Name = "labelCustomerID";
            this.labelCustomerID.Size = new System.Drawing.Size(125, 17);
            this.labelCustomerID.TabIndex = 10;
            this.labelCustomerID.Text = "Enter customer ID:";
            // 
            // labelQuantity
            // 
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Location = new System.Drawing.Point(188, 101);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(151, 17);
            this.labelQuantity.TabIndex = 11;
            this.labelQuantity.Text = "Enter desired quantity:";
            // 
            // labelProducts
            // 
            this.labelProducts.AutoSize = true;
            this.labelProducts.Location = new System.Drawing.Point(188, 139);
            this.labelProducts.Name = "labelProducts";
            this.labelProducts.Size = new System.Drawing.Size(63, 17);
            this.labelProducts.TabIndex = 12;
            this.labelProducts.Text = "products";
            // 
            // textBoxOrderID
            // 
            this.textBoxOrderID.Location = new System.Drawing.Point(426, 42);
            this.textBoxOrderID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxOrderID.Name = "textBoxOrderID";
            this.textBoxOrderID.Size = new System.Drawing.Size(136, 22);
            this.textBoxOrderID.TabIndex = 13;
            // 
            // textBoxNewQuantity
            // 
            this.textBoxNewQuantity.Location = new System.Drawing.Point(715, 101);
            this.textBoxNewQuantity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxNewQuantity.Name = "textBoxNewQuantity";
            this.textBoxNewQuantity.Size = new System.Drawing.Size(136, 22);
            this.textBoxNewQuantity.TabIndex = 14;
            // 
            // labelOrderID
            // 
            this.labelOrderID.AutoSize = true;
            this.labelOrderID.Location = new System.Drawing.Point(341, 47);
            this.labelOrderID.Name = "labelOrderID";
            this.labelOrderID.Size = new System.Drawing.Size(62, 17);
            this.labelOrderID.TabIndex = 15;
            this.labelOrderID.Text = "Order ID";
            // 
            // labelNewQuantity
            // 
            this.labelNewQuantity.AutoSize = true;
            this.labelNewQuantity.Location = new System.Drawing.Point(579, 106);
            this.labelNewQuantity.Name = "labelNewQuantity";
            this.labelNewQuantity.Size = new System.Drawing.Size(91, 17);
            this.labelNewQuantity.TabIndex = 16;
            this.labelNewQuantity.Text = "new quantity:";
            // 
            // buttonModifyOrder
            // 
            this.buttonModifyOrder.Location = new System.Drawing.Point(603, 127);
            this.buttonModifyOrder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonModifyOrder.Name = "buttonModifyOrder";
            this.buttonModifyOrder.Size = new System.Drawing.Size(184, 28);
            this.buttonModifyOrder.TabIndex = 17;
            this.buttonModifyOrder.Text = "modify order";
            this.buttonModifyOrder.UseVisualStyleBackColor = true;
            this.buttonModifyOrder.Click += new System.EventHandler(this.buttonModifyOrder_Click);
            // 
            // textBoxOrders
            // 
            this.textBoxOrders.Location = new System.Drawing.Point(245, 166);
            this.textBoxOrders.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxOrders.Multiline = true;
            this.textBoxOrders.Name = "textBoxOrders";
            this.textBoxOrders.Size = new System.Drawing.Size(352, 194);
            this.textBoxOrders.TabIndex = 18;
            // 
            // buttonBackToMenu
            // 
            this.buttonBackToMenu.Location = new System.Drawing.Point(17, 325);
            this.buttonBackToMenu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonBackToMenu.Name = "buttonBackToMenu";
            this.buttonBackToMenu.Size = new System.Drawing.Size(150, 34);
            this.buttonBackToMenu.TabIndex = 19;
            this.buttonBackToMenu.Text = "back to menu";
            this.buttonBackToMenu.UseVisualStyleBackColor = true;
            this.buttonBackToMenu.Click += new System.EventHandler(this.buttonBackToMenu_Click);
            // 
            // buttonDeleteOrder
            // 
            this.buttonDeleteOrder.Location = new System.Drawing.Point(418, 113);
            this.buttonDeleteOrder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonDeleteOrder.Name = "buttonDeleteOrder";
            this.buttonDeleteOrder.Size = new System.Drawing.Size(151, 23);
            this.buttonDeleteOrder.TabIndex = 20;
            this.buttonDeleteOrder.Text = "Delete order";
            this.buttonDeleteOrder.UseVisualStyleBackColor = true;
            this.buttonDeleteOrder.Click += new System.EventHandler(this.buttonDeleteOrder_Click);
            // 
            // buttonEnter
            // 
            this.buttonEnter.Location = new System.Drawing.Point(344, 84);
            this.buttonEnter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonEnter.Name = "buttonEnter";
            this.buttonEnter.Size = new System.Drawing.Size(77, 25);
            this.buttonEnter.TabIndex = 21;
            this.buttonEnter.Text = "Enter";
            this.buttonEnter.UseVisualStyleBackColor = true;
            this.buttonEnter.Click += new System.EventHandler(this.buttonEnter_Click);
            // 
            // listBoxOrders
            // 
            this.listBoxOrders.FormattingEnabled = true;
            this.listBoxOrders.ItemHeight = 16;
            this.listBoxOrders.Location = new System.Drawing.Point(172, 166);
            this.listBoxOrders.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBoxOrders.Name = "listBoxOrders";
            this.listBoxOrders.Size = new System.Drawing.Size(1072, 180);
            this.listBoxOrders.TabIndex = 22;
            this.listBoxOrders.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // buttonReadOrder
            // 
            this.buttonReadOrder.Location = new System.Drawing.Point(439, 78);
            this.buttonReadOrder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonReadOrder.Name = "buttonReadOrder";
            this.buttonReadOrder.Size = new System.Drawing.Size(123, 31);
            this.buttonReadOrder.TabIndex = 23;
            this.buttonReadOrder.Text = "read order";
            this.buttonReadOrder.UseVisualStyleBackColor = true;
            this.buttonReadOrder.Click += new System.EventHandler(this.buttonReadOrder_Click);
            // 
            // OrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1331, 368);
            this.Controls.Add(this.buttonReadOrder);
            this.Controls.Add(this.listBoxOrders);
            this.Controls.Add(this.buttonEnter);
            this.Controls.Add(this.buttonDeleteOrder);
            this.Controls.Add(this.buttonBackToMenu);
            this.Controls.Add(this.textBoxOrders);
            this.Controls.Add(this.buttonModifyOrder);
            this.Controls.Add(this.labelNewQuantity);
            this.Controls.Add(this.labelOrderID);
            this.Controls.Add(this.textBoxNewQuantity);
            this.Controls.Add(this.textBoxOrderID);
            this.Controls.Add(this.labelProducts);
            this.Controls.Add(this.labelQuantity);
            this.Controls.Add(this.labelCustomerID);
            this.Controls.Add(this.buttonPlaceOrder);
            this.Controls.Add(this.listBoxProductNumbers);
            this.Controls.Add(this.textBoxQuantity);
            this.Controls.Add(this.textBoxCustomerID);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonReadAll);
            this.Controls.Add(this.buttonRead);
            this.Controls.Add(this.buttonModify);
            this.Controls.Add(this.buttonNew);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "OrderForm";
            this.Text = "OrderForm";
            this.Load += new System.EventHandler(this.OrderForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonNew;
        private System.Windows.Forms.Button buttonModify;
        private System.Windows.Forms.Button buttonRead;
        private System.Windows.Forms.Button buttonReadAll;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.TextBox textBoxCustomerID;
        private System.Windows.Forms.TextBox textBoxQuantity;
        private System.Windows.Forms.ListBox listBoxProductNumbers;
        private System.Windows.Forms.Button buttonPlaceOrder;
        private System.Windows.Forms.Label labelCustomerID;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.Label labelProducts;
        private System.Windows.Forms.TextBox textBoxOrderID;
        private System.Windows.Forms.TextBox textBoxNewQuantity;
        private System.Windows.Forms.Label labelOrderID;
        private System.Windows.Forms.Label labelNewQuantity;
        private System.Windows.Forms.Button buttonModifyOrder;
        private System.Windows.Forms.TextBox textBoxOrders;
        private System.Windows.Forms.Button buttonBackToMenu;
        private System.Windows.Forms.Button buttonDeleteOrder;
        private System.Windows.Forms.Button buttonEnter;
        private System.Windows.Forms.ListBox listBoxOrders;
        private System.Windows.Forms.Button buttonReadOrder;
    }
}