﻿
namespace UI_Layer
{
    partial class ProductFormNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxAmountInStock = new System.Windows.Forms.TextBox();
            this.textBoxCostPerUnit = new System.Windows.Forms.TextBox();
            this.textBoxProductName = new System.Windows.Forms.TextBox();
            this.textBoxProductNum = new System.Windows.Forms.TextBox();
            this.labelNumberInStock = new System.Windows.Forms.Label();
            this.labelCostPerUnit = new System.Windows.Forms.Label();
            this.labelProductName = new System.Windows.Forms.Label();
            this.labelProductNum = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonModifyEnter
            // 
            this.buttonModifyEnter.Click += new System.EventHandler(this.buttonModifyEnter_Click);
            // 
            // buttonModify
            // 
            this.buttonModify.Click += new System.EventHandler(this.buttonModify_Click);
            // 
            // ButtonBackToMenu
            // 
            this.ButtonBackToMenu.Click += new System.EventHandler(this.ButtonBackToMenu_Click);
            // 
            // buttonShow
            // 
            this.buttonShow.Click += new System.EventHandler(this.buttonShow_Click);
            // 
            // buttonNew
            // 
            this.buttonNew.Location = new System.Drawing.Point(12, 21);
            this.buttonNew.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonNew.Click += new System.EventHandler(this.buttonNew_Click);
            // 
            // textBoxReadAll
            // 
            this.textBoxReadAll.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxReadAll.Size = new System.Drawing.Size(306, 320);
            // 
            // ButtonDeleteEnter
            // 
            this.ButtonDeleteEnter.Click += new System.EventHandler(this.ButtonDeleteEnter_Click);
            // 
            // buttonEnterNew
            // 
            this.buttonEnterNew.Click += new System.EventHandler(this.buttonEnterNew_Click);
            // 
            // buttonEnterShowOne
            // 
            this.buttonEnterShowOne.Click += new System.EventHandler(this.buttonEnterShowOne_Click);
            // 
            // textBoxAmountInStock
            // 
            this.textBoxAmountInStock.Font = new System.Drawing.Font("Segoe Print", 8F);
            this.textBoxAmountInStock.Location = new System.Drawing.Point(273, 190);
            this.textBoxAmountInStock.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxAmountInStock.Name = "textBoxAmountInStock";
            this.textBoxAmountInStock.Size = new System.Drawing.Size(218, 31);
            this.textBoxAmountInStock.TabIndex = 43;
            // 
            // textBoxCostPerUnit
            // 
            this.textBoxCostPerUnit.Font = new System.Drawing.Font("Segoe Print", 8F);
            this.textBoxCostPerUnit.Location = new System.Drawing.Point(273, 154);
            this.textBoxCostPerUnit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxCostPerUnit.Name = "textBoxCostPerUnit";
            this.textBoxCostPerUnit.Size = new System.Drawing.Size(218, 31);
            this.textBoxCostPerUnit.TabIndex = 44;
            // 
            // textBoxProductName
            // 
            this.textBoxProductName.Font = new System.Drawing.Font("Segoe Print", 8F);
            this.textBoxProductName.Location = new System.Drawing.Point(273, 114);
            this.textBoxProductName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxProductName.Name = "textBoxProductName";
            this.textBoxProductName.Size = new System.Drawing.Size(218, 31);
            this.textBoxProductName.TabIndex = 45;
            // 
            // textBoxProductNum
            // 
            this.textBoxProductNum.Font = new System.Drawing.Font("Segoe Print", 8F);
            this.textBoxProductNum.Location = new System.Drawing.Point(273, 67);
            this.textBoxProductNum.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxProductNum.Name = "textBoxProductNum";
            this.textBoxProductNum.Size = new System.Drawing.Size(218, 31);
            this.textBoxProductNum.TabIndex = 46;
            // 
            // labelNumberInStock
            // 
            this.labelNumberInStock.AutoSize = true;
            this.labelNumberInStock.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumberInStock.Location = new System.Drawing.Point(54, 192);
            this.labelNumberInStock.Name = "labelNumberInStock";
            this.labelNumberInStock.Size = new System.Drawing.Size(138, 26);
            this.labelNumberInStock.TabIndex = 47;
            this.labelNumberInStock.Text = "amount in stock:";
            // 
            // labelCostPerUnit
            // 
            this.labelCostPerUnit.AutoSize = true;
            this.labelCostPerUnit.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCostPerUnit.Location = new System.Drawing.Point(54, 154);
            this.labelCostPerUnit.Name = "labelCostPerUnit";
            this.labelCostPerUnit.Size = new System.Drawing.Size(113, 26);
            this.labelCostPerUnit.TabIndex = 48;
            this.labelCostPerUnit.Text = "cost per unit:";
            // 
            // labelProductName
            // 
            this.labelProductName.AutoSize = true;
            this.labelProductName.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProductName.Location = new System.Drawing.Point(58, 114);
            this.labelProductName.Name = "labelProductName";
            this.labelProductName.Size = new System.Drawing.Size(124, 26);
            this.labelProductName.TabIndex = 49;
            this.labelProductName.Text = "product name:";
            // 
            // labelProductNum
            // 
            this.labelProductNum.AutoSize = true;
            this.labelProductNum.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProductNum.Location = new System.Drawing.Point(54, 67);
            this.labelProductNum.Name = "labelProductNum";
            this.labelProductNum.Size = new System.Drawing.Size(144, 26);
            this.labelProductNum.TabIndex = 50;
            this.labelProductNum.Text = "Product Number:";
            // 
            // ProductFormNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1159, 474);
            this.Controls.Add(this.labelProductNum);
            this.Controls.Add(this.labelProductName);
            this.Controls.Add(this.labelCostPerUnit);
            this.Controls.Add(this.labelNumberInStock);
            this.Controls.Add(this.textBoxProductNum);
            this.Controls.Add(this.textBoxProductName);
            this.Controls.Add(this.textBoxCostPerUnit);
            this.Controls.Add(this.textBoxAmountInStock);
            this.Name = "ProductFormNew";
            this.Text = "ProductFormNew";
            this.Load += new System.EventHandler(this.ProductFormNew_Load);
            this.Controls.SetChildIndex(this.textBoxAmountInStock, 0);
            this.Controls.SetChildIndex(this.buttonNew, 0);
            this.Controls.SetChildIndex(this.ButtonShowAll, 0);
            this.Controls.SetChildIndex(this.buttonShow, 0);
            this.Controls.SetChildIndex(this.buttonDelete, 0);
            this.Controls.SetChildIndex(this.ButtonBackToMenu, 0);
            this.Controls.SetChildIndex(this.buttonModify, 0);
            this.Controls.SetChildIndex(this.buttonModifyEnter, 0);
            this.Controls.SetChildIndex(this.textBoxReadAll, 0);
            this.Controls.SetChildIndex(this.InventoryLabel, 0);
            this.Controls.SetChildIndex(this.buttonEnterShowOne, 0);
            this.Controls.SetChildIndex(this.buttonEnterNew, 0);
            this.Controls.SetChildIndex(this.ButtonDeleteEnter, 0);
            this.Controls.SetChildIndex(this.textBoxCostPerUnit, 0);
            this.Controls.SetChildIndex(this.textBoxProductName, 0);
            this.Controls.SetChildIndex(this.textBoxProductNum, 0);
            this.Controls.SetChildIndex(this.labelNumberInStock, 0);
            this.Controls.SetChildIndex(this.labelCostPerUnit, 0);
            this.Controls.SetChildIndex(this.labelProductName, 0);
            this.Controls.SetChildIndex(this.labelProductNum, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxAmountInStock;
        private System.Windows.Forms.TextBox textBoxCostPerUnit;
        private System.Windows.Forms.TextBox textBoxProductName;
        private System.Windows.Forms.TextBox textBoxProductNum;
        private System.Windows.Forms.Label labelNumberInStock;
        private System.Windows.Forms.Label labelCostPerUnit;
        private System.Windows.Forms.Label labelProductName;
        private System.Windows.Forms.Label labelProductNum;
    }
}