﻿
namespace UI_Layer
{
    partial class customerFormNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelCustomerIDNEW = new System.Windows.Forms.Label();
            this.labelCustomerNameNEW = new System.Windows.Forms.Label();
            this.labelCustomerCreditCardNEW = new System.Windows.Forms.Label();
            this.textBoxCustomerCreditCardNEW = new System.Windows.Forms.TextBox();
            this.textBoxCustomerNameNEW = new System.Windows.Forms.TextBox();
            this.textBoxCustomerIdNEW = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonModifyEnter
            // 
            this.buttonModifyEnter.Click += new System.EventHandler(this.buttonModifyEnter_Click_1);
            // 
            // buttonModify
            // 
            this.buttonModify.Click += new System.EventHandler(this.buttonModify_Click);
            // 
            // ButtonBackToMenu
            // 
            this.ButtonBackToMenu.Click += new System.EventHandler(this.ButtonBackToMenu_Click_1);
            // 
            // buttonShow
            // 
            this.buttonShow.Click += new System.EventHandler(this.buttonShow_Click);
            // 
            // ButtonShowAll
            // 
            this.ButtonShowAll.Click += new System.EventHandler(this.ButtonShowAll_Click_1);
            // 
            // textBoxReadAll
            // 
            this.textBoxReadAll.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxReadAll.Size = new System.Drawing.Size(306, 320);
            // 
            // InventoryLabel
            // 
            this.InventoryLabel.Location = new System.Drawing.Point(762, 42);
            this.InventoryLabel.Size = new System.Drawing.Size(326, 35);
            this.InventoryLabel.Text = "These are your customers:";
            // 
            // ButtonDeleteEnter
            // 
            this.ButtonDeleteEnter.Click += new System.EventHandler(this.ButtonDeleteEnter_Click);
            // 
            // buttonEnterNew
            // 
            this.buttonEnterNew.Click += new System.EventHandler(this.buttonEnterNew_Click_1);
            // 
            // buttonEnterShowOne
            // 
            this.buttonEnterShowOne.Click += new System.EventHandler(this.buttonEnterShowOne_Click_1);
            // 
            // labelCustomerIDNEW
            // 
            this.labelCustomerIDNEW.AutoSize = true;
            this.labelCustomerIDNEW.Font = new System.Drawing.Font("Segoe Print", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCustomerIDNEW.Location = new System.Drawing.Point(22, 42);
            this.labelCustomerIDNEW.Name = "labelCustomerIDNEW";
            this.labelCustomerIDNEW.Size = new System.Drawing.Size(121, 30);
            this.labelCustomerIDNEW.TabIndex = 45;
            this.labelCustomerIDNEW.Text = "Customer ID";
            this.labelCustomerIDNEW.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelCustomerNameNEW
            // 
            this.labelCustomerNameNEW.AutoSize = true;
            this.labelCustomerNameNEW.Font = new System.Drawing.Font("Segoe Print", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCustomerNameNEW.Location = new System.Drawing.Point(22, 94);
            this.labelCustomerNameNEW.Name = "labelCustomerNameNEW";
            this.labelCustomerNameNEW.Size = new System.Drawing.Size(154, 30);
            this.labelCustomerNameNEW.TabIndex = 46;
            this.labelCustomerNameNEW.Text = "Customer name:";
            // 
            // labelCustomerCreditCardNEW
            // 
            this.labelCustomerCreditCardNEW.AutoSize = true;
            this.labelCustomerCreditCardNEW.Font = new System.Drawing.Font("Segoe Print", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCustomerCreditCardNEW.Location = new System.Drawing.Point(22, 146);
            this.labelCustomerCreditCardNEW.Name = "labelCustomerCreditCardNEW";
            this.labelCustomerCreditCardNEW.Size = new System.Drawing.Size(210, 30);
            this.labelCustomerCreditCardNEW.TabIndex = 47;
            this.labelCustomerCreditCardNEW.Text = "Customer Credit Card:";
            // 
            // textBoxCustomerCreditCardNEW
            // 
            this.textBoxCustomerCreditCardNEW.Font = new System.Drawing.Font("Segoe Print", 8F);
            this.textBoxCustomerCreditCardNEW.Location = new System.Drawing.Point(260, 146);
            this.textBoxCustomerCreditCardNEW.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxCustomerCreditCardNEW.Name = "textBoxCustomerCreditCardNEW";
            this.textBoxCustomerCreditCardNEW.Size = new System.Drawing.Size(185, 31);
            this.textBoxCustomerCreditCardNEW.TabIndex = 48;
            // 
            // textBoxCustomerNameNEW
            // 
            this.textBoxCustomerNameNEW.Font = new System.Drawing.Font("Segoe Print", 8F);
            this.textBoxCustomerNameNEW.Location = new System.Drawing.Point(265, 96);
            this.textBoxCustomerNameNEW.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxCustomerNameNEW.Name = "textBoxCustomerNameNEW";
            this.textBoxCustomerNameNEW.Size = new System.Drawing.Size(180, 31);
            this.textBoxCustomerNameNEW.TabIndex = 49;
            // 
            // textBoxCustomerIdNEW
            // 
            this.textBoxCustomerIdNEW.Font = new System.Drawing.Font("Segoe Print", 8F);
            this.textBoxCustomerIdNEW.Location = new System.Drawing.Point(265, 44);
            this.textBoxCustomerIdNEW.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxCustomerIdNEW.Name = "textBoxCustomerIdNEW";
            this.textBoxCustomerIdNEW.Size = new System.Drawing.Size(180, 31);
            this.textBoxCustomerIdNEW.TabIndex = 50;
            // 
            // customerFormNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.ClientSize = new System.Drawing.Size(1133, 495);
            this.Controls.Add(this.textBoxCustomerIdNEW);
            this.Controls.Add(this.textBoxCustomerNameNEW);
            this.Controls.Add(this.textBoxCustomerCreditCardNEW);
            this.Controls.Add(this.labelCustomerCreditCardNEW);
            this.Controls.Add(this.labelCustomerNameNEW);
            this.Controls.Add(this.labelCustomerIDNEW);
            this.Name = "customerFormNew";
            this.Text = "CustomerForm";
            this.Load += new System.EventHandler(this.customerFormNew_Load_1);
            this.Controls.SetChildIndex(this.buttonNew, 0);
            this.Controls.SetChildIndex(this.ButtonShowAll, 0);
            this.Controls.SetChildIndex(this.buttonShow, 0);
            this.Controls.SetChildIndex(this.buttonDelete, 0);
            this.Controls.SetChildIndex(this.ButtonBackToMenu, 0);
            this.Controls.SetChildIndex(this.buttonModify, 0);
            this.Controls.SetChildIndex(this.buttonModifyEnter, 0);
            this.Controls.SetChildIndex(this.textBoxReadAll, 0);
            this.Controls.SetChildIndex(this.InventoryLabel, 0);
            this.Controls.SetChildIndex(this.buttonEnterShowOne, 0);
            this.Controls.SetChildIndex(this.buttonEnterNew, 0);
            this.Controls.SetChildIndex(this.ButtonDeleteEnter, 0);
            this.Controls.SetChildIndex(this.labelCustomerIDNEW, 0);
            this.Controls.SetChildIndex(this.labelCustomerNameNEW, 0);
            this.Controls.SetChildIndex(this.labelCustomerCreditCardNEW, 0);
            this.Controls.SetChildIndex(this.textBoxCustomerCreditCardNEW, 0);
            this.Controls.SetChildIndex(this.textBoxCustomerNameNEW, 0);
            this.Controls.SetChildIndex(this.textBoxCustomerIdNEW, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelCustomerID;
        private System.Windows.Forms.Label labelCustomerName;
        private System.Windows.Forms.Label labelCustomerCreditCard;
        private System.Windows.Forms.TextBox textBoxCustomerID;
        private System.Windows.Forms.TextBox textBoxCustomerName;
        private System.Windows.Forms.TextBox textBoxCustomerCreditCard;
        private System.Windows.Forms.Label labelShow;
        private System.Windows.Forms.Label labelDelete;
        private System.Windows.Forms.Label labelCustomerIDNEW;
        private System.Windows.Forms.Label labelCustomerNameNEW;
        private System.Windows.Forms.Label labelCustomerCreditCardNEW;
        private System.Windows.Forms.TextBox textBoxCustomerCreditCardNEW;
        private System.Windows.Forms.TextBox textBoxCustomerNameNEW;
        private System.Windows.Forms.TextBox textBoxCustomerIdNEW;
    }
}