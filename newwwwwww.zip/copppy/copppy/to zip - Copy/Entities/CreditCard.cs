﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
   public class CreditCard
    {//class CreditCard, initializing the properties necessary
        public string OwnerName { get; set; }
        public string CardNumber { get; set; }
        public DateTime ExpirationDate { get; set; }
        public double Charges { get; set; }

        //constructor to initialize CreditCard
        public CreditCard(string ownerName, string cardNum, DateTime expiration, double charge=0)
        {
            OwnerName = ownerName;
            if (expiration == default(DateTime))
            { ExpirationDate = DateTime.Now.AddYears(5); }
            else
            { ExpirationDate = expiration; }

            CardNumber = cardNum;
            Charges = charge;
        }
        public override string ToString()
        {
            return $"Name on card: { OwnerName} \n Crd number is: {CardNumber}\n expires: {ExpirationDate.ToShortDateString()}\n charges:{Charges}";

        }

    }
}
