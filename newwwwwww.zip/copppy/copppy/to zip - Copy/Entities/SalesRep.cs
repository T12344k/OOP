﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class SalesRep: Employee
    {
        //property for commision rate
        public double CommisionRate { get; set; }

     /// <summary>
     /// constructor for the commission rate
     /// </summary>
     /// <param name="nname">name of sales rep</param>
     /// <param name="iid">id of sales rep</param>
     /// <param name="salary">salary of salesrep </param>
     /// <param name="commisionRate">commission rate of salesrep<mmiss/param>
        public SalesRep (string nname, string iid, double salary, double commisionRate): base (nname, iid, salary)
        {
            CommisionRate = commisionRate;
        }

    }
}
