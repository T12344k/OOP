﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Product
    {
        //product number property
        public string Product_Number { get; set; }
        //product name property
        public string Product_Name { get; set; }
        //cost per unir property
        public double Cost_Per_Unit { get; set; }
        public int AmountInStock { get; set; }


        /// <summary>
        /// ctor to initialize property values
        /// </summary>
        /// <param name="productNumber">set as Product_Number</param>
        /// <param name="productName">set as Product_Name</param>
        /// <param name="costPerUnit">set as Cost_Per_Unit</param>
        public Product (string productNumber="", string productName="", double costPerUnit=0, int amountInStock=0)
        {
            Product_Number = productNumber;
            Product_Name = productName;
            Cost_Per_Unit = costPerUnit;
            AmountInStock = amountInStock;
        }

        /// <summary>
        /// to string method for product. 
        /// </summary>
        /// <returns>properties of product</returns>
        public override string ToString()
        {//ToString method for the several attributs of product. 
            return $"Product number is: {Product_Number}  " +
                $"\r\nProduct name is:{Product_Name}  \r\n" +
                $"Cost per unit is: {Cost_Per_Unit}  \r\n"+
                $"Amount left in stock is: {AmountInStock}\r\n";
        }
    }
}