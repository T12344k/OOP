﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using DAL;

namespace BL
{
    class BlTest
    {
        static void Main(string[] args)
        {
            {
                try
                {
                  
                    OrderBLL orderDal = new OrderBLL(); //creating a new object of OrderBLL
                    
                    orderDal.Create("123", "1234567687987", 4);//creating a new Order
                    foreach (var ord in orderDal.ReadAll()) //reading all the information about the order. 
                    {
                        Console.WriteLine(ord);
                    }
                    Order or = new Order("123", "576", 7);// creating another new order 
                    foreach (var ord in orderDal.ReadAll())
                    {
                        Console.WriteLine(ord);//reading all the infromation about this order. 
                    }
                    Console.WriteLine("READ \n");
                    Console.WriteLine(orderDal.Read(1)); 
                    orderDal.Create("123", "44444", 3);
                    Console.WriteLine("CREATED\n");
                    Console.WriteLine("deleted #2 \n");
                    Console.WriteLine("updated order");
                    foreach (var ord in orderDal.ReadAll())
                    {
                        Console.WriteLine(ord);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
