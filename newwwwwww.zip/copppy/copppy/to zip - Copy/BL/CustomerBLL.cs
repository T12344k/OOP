﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.IO;
using DAL;

namespace BL
{
   public class CustomerBLL
    {
         CustomerDAL crDAL = new CustomerDAL();//creating a new customer of type customerDAL. 
        public void Create(string crID, string crName, CreditCard crCard)//giving it the parameters of customer attribute
        {//throwing everything into a try and catch, in case it doesnt work it throws an exception. 
            try   
            {
                crDAL.Create(crID, crName, crCard);//trying to crete the cusotmer. 
            }
            catch
            {
                throw;//in case it doesn't work, the program should throw an exception. 
            }
        }
        //read specific customer
        public Customer Read (string toSee)// reading the information about a particular customer. 
        {
           return crDAL.Read(toSee);
        }


        //reads all customers with their information
        public List<Customer> ReadAll()
        {
           return crDAL.ReadAll();
        }
        public Customer ReadbyID(string CustomerID)//reads the customers' information by user giving in the customerID
        {
            if (crDAL.ReadAll().FirstOrDefault(x => x.ID == CustomerID) != null)
                return crDAL.ReadAll().FirstOrDefault(x => x.ID == CustomerID);
            else
            {
                throw new Exception("Your customer ID was not found.\n Please enter a new one. ");
            }
            
        }

        //updates a customer
        public bool Update(string CustomerID, Customer customer1)
        {
           return crDAL.Update(CustomerID, customer1);
        }
 
        //deleting a customer
        public bool Delete(string toDelete)
            //returning the deleted customer
        {
            return crDAL.Delete(toDelete);
        }
    }
}
