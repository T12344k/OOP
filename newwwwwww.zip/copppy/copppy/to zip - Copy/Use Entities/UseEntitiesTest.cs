﻿using System;
using System.Collections.Generic;//will recognize list
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.IO;



namespace Use_Entities
{
    public class UseEntitiesTest
    {
        static void Main(string[] args)
        {
            //create new person object. Not used in the end, because next I created an array
            Person person1 = new Person("Chani", "789");
            //new product object
            Product product1 = new Product("5678", "microphone", 5.89,7);//i added to the parameter  amountinstock here. 

            //create array of Person
            Person [] personArray = new Person[5];
            
            //create an object of StreamReader to read textfile
      StreamReader reader = new StreamReader("person2.txt");

            using (reader)
            {
                string line = reader.ReadLine();
                //next line for ID of person
                string line2 = reader.ReadLine();


                //for each index in array 
                for (int i = 0; i<personArray.Length; i++)
                {

                    //initialize person with txt file samples
                    Person personA = new Person (line, line2 );
                    //add person to array
                    personArray[i] = personA;
                    line = reader.ReadLine();
                    line2 = reader.ReadLine();
                }
            }

            //display ppl in array
            foreach (Person guy in personArray)
            {

                Console.WriteLine(guy);
                 
            }
            
            DateTime dt = new DateTime(2004, 5, 31);

            CreditCard myCard = new CreditCard("Yael Abramowitz", "5678678967895432", dt, 78.89);

            Customer cus = new Customer(myCard, "UglyGuy", "100987543");
            
        }


    }
}
