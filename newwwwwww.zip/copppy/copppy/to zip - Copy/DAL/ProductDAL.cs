﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Entities;

namespace DAL
{
    public class ProductDAL
    {
        //create list of products
        static bool ListInitialized=false;
        static List<Product> productlist = new List<Product>();
        #region ***c-tor*** 

        /// <summary>
        ///initialize list; read in values
        /// </summary>
        public void Initializelist()
        {
            StreamReader textfile = new StreamReader("ProductInfo1.txt"); //finding the text file 
            string productstring;
            for (int i = 0; (productstring = textfile.ReadLine()) != null; i++) //checks if the textfile still contains people .
            {   //split method for every product of the textfile
                 string[] array = productstring.Split(',');
                //putting the info into a new product.
                Product info = new Product(array[0], array[1], double.Parse(array[2]), int.Parse(array[3]));
                productlist.Add(info);
                ListInitialized = true;
            }

        }

        /// <summary>
        /// ctor to initialize list
        /// </summary>
        public ProductDAL()
        {
            if (ListInitialized == false)
                   Initializelist();
           
        }
        #endregion


        /// <summary>
        /// create/ add to list
        /// </summary>
        /// 
        public void Create (string productNum, string productName, double cost,int amountIn)
        {


            string productNumber = productNum;
            //add this
            if (productlist.Find(x => (x.Product_Number) == productNumber) != null)//if the productnumber already exists in the list, it should throw an exception. 
            {
                throw new Exception("This product number already exists. Please enter a different one. ");

            }
            productlist.Add(new Product(productNum, productName, cost, amountIn)); //creating  a new product. 
        }


        /// <summary>
        /// read list
        /// </summary>
        public Product Read(string toSee)//reading the info about a particular product. 
        {
            bool seen = false;
            Product copied;

            foreach (Product pr in productlist)
            {
                if (pr.Product_Number == toSee)
                {
                    copied = new Product(pr.Product_Number,pr.Product_Name,pr.Cost_Per_Unit, pr.AmountInStock);
                    return copied;
                  
                    //returns a COPY of the product information. 
                }

            }
            if (seen ==false)
            {
                throw new Exception("This product was not found on the list, please check your spelling.");
                //throws an exception if the product couldnt be found. 
            }
            return null;
        }

        /// <summary>
        /// read full list
        /// </summary>
        public List<Product> ReadAll ()//shows all information about a product. 
        {
            List<Product> newProductList = productlist.ConvertAll(product => new Product(product.Product_Number, product.Product_Name, product.Cost_Per_Unit, product.AmountInStock));
            return newProductList;
        }


        /// <summary>
        /// update list
        /// </summary>
        public bool Update (string toUpdate, Product prod)//updates a product. 
        {
            bool upDated = false;
            int indexToUpdate=0;  //becuase a foreach does not have an index
            
        
                foreach (Product pr in productlist)//checks if the product ID exists on the list and is the one i am lookng for to update. 
                {
                    if (pr.Product_Number == toUpdate)
                    {
            
                    productlist[indexToUpdate] = prod; 
                         upDated = true;
                    break;
                    }
                indexToUpdate++;
                }

                if (upDated==false)
            {
                throw new Exception("The product ID could not be found.");//throws an exception i product number couldnt be found. 
            }

            return upDated;
        }


        /// <summary>
        /// delete from list
        /// </summary>
        public bool Delete (string toDelete)// deletes a product. 
        {
            bool deleted = false;

            foreach (Product pr in productlist)
            {
                if (pr.Product_Number == toDelete)//checks if the product number of the product i wanna delete exists on the list. 
                {
                    productlist.Remove(pr);
                    deleted = true;
                    break;
                }
                
            }
            if (deleted==false)
            {
                throw new Exception("this product was not on the list. Please check spelling.");
            }
            return true;
        }
    }
}

