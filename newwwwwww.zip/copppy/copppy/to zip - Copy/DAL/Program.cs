﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;

namespace DAL
{
    class Program
    {
        //testing the CRUD methods on order. 
        static void Main(string[] args)
        {
            OrderDal orderDal = new OrderDal();
            orderDal.Create("123", "1234567687987", 4);
          foreach (var ord in orderDal.ReadEverything())
            {
                Console.WriteLine(ord);
            }
            Order or = new Order("123", "576", 7);
           orderDal.Update(1, or);
            foreach (var ord in orderDal.ReadEverything())
            {
                Console.WriteLine(ord);
            }
            Console.WriteLine("READ \n");
            orderDal.Read(1);
            orderDal.Create("123", "44444", 3);
            Console.WriteLine("CREATED\n");
            orderDal.DeleteOrder(2);
            Console.WriteLine("deleted #2 \n");
            //foreach (var ord in orderDal.ReadEverything())
            //{
            //    Console.WriteLine(ord);
            //}
            orderDal.Update(1, or);
            Console.WriteLine("updated order");
            foreach (var ord in orderDal.ReadEverything())
            {
                Console.WriteLine(ord);
            }





        }
    }
}
